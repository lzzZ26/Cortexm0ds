// tb_fir_para_impulse.v : Q18验收波形——通用并行核 + 冲激响应
// 默认非对称系数；可用参数切对称系数（tb_fir_para_impulse_sym包装）。
// 原理：输入首样本为冲激 0x7FFF、其后为 0；FIR 前 82 个输出即冲激响应，
//       应逐个等于 c[n]×0x7FFF（Q1.31）——对称系数左右镜像、非对称明显不同。
// 自检：前82个输出与 golden 前82行**逐位相等**（单乘积精确）。
`timescale 1ns/1ps
module tb_fir_para_impulse #(
  parameter COEFF_FILE  = "tb/data/coeff_asym_q15.hex",
  parameter GOLDEN_FILE = "tb/data/golden_asym_q31.hex",
  parameter VCD_FILE    = "sim_out/q18_impulse.vcd",
  parameter CSV_FILE    = "sim_out/q18_impulse.csv",
  parameter TAG         = "asym"
);
  wire clk, rstn;
  reg  clr;
  reg  cfg_we; reg [9:0] cfg_addr; reg [15:0] cfg_wdata;
  reg  din_valid; wire din_ready; reg [15:0] din;
  wire dout_valid; reg dout_ready; wire [31:0] dout;

  reg [15:0] coeff [0:81];
  reg [31:0] golden [0:1023];
  integer n, out_cnt, err_cnt, fd;
  reg [31:0] cap [0:127];

  tb_clkreset #(.RESET_CYCLES(5)) u_ck (.clk(clk), .rstn(rstn));

  fir_core_para #(.TAPS(82), .CW(16), .DW(16)) u_fir (
    .ACLK(clk), .ARESETn(rstn), .clr(clr),
    .cfg_we(cfg_we), .cfg_addr(cfg_addr), .cfg_wdata(cfg_wdata),
    .din_valid(din_valid), .din_ready(din_ready), .din(din),
    .dout_valid(dout_valid), .dout_ready(dout_ready), .dout(dout));

  initial begin
    $readmemh(COEFF_FILE, coeff);
    $readmemh(GOLDEN_FILE, golden);
  end

  // 仅用于VCD的干净probe：只含关键信号，避免字符串参数/大数组进波形
  // （GTKWave对$var parameter显示为xxxx，会误以为整条波形无效）
  q18_wave_probe u_probe (
    .clk(clk), .rstn(rstn), .clr(clr),
    .din_valid(din_valid), .din_ready(din_ready), .din(din),
    .dout_valid(dout_valid), .dout_ready(dout_ready), .dout(dout));

  // VCD从时间0开始录（probe只含关键信号）——波形总长约2us，Zoom-Fit即全部
  initial begin
    $dumpfile(VCD_FILE);
    $dumpvars(0, tb_fir_para_impulse.u_probe);
  end

  initial begin
    clr = 0; cfg_we = 0; cfg_addr = 0; cfg_wdata = 0;
    din_valid = 0; din = 0; dout_ready = 1;
    out_cnt = 0; err_cnt = 0;
    wait (rstn == 1'b1);
    @(posedge clk);   // 越过复位释放沿，避免与核always的复位分支竞争
    // 波形用例专用：直接初始化核内系数寄存器，省去82项配置段（约3.3us），
    // 使VCD从复位后立即进入冲激响应。系数配置接口的功能验证见
    // tb_fir_core_para 用例F（cfg逐系数写/覆盖写回归）。
    for (n = 0; n < 82; n = n + 1) u_fir.c[n] = coeff[n];
    // CLR（NBA，避免与核always的delta竞争）
    @(negedge clk); clr <= 1'b1;
    @(negedge clk); clr <= 1'b0;
    // 冲激 + 81个零（82样本），negedge驱动保证posedge稳定
    for (n = 0; n < 82; n = n + 1) begin
      @(negedge clk);
      din_valid = 1;
      din = (n == 0) ? 16'h7FFF : 16'h0000;
    end
    @(negedge clk); din_valid = 0;
    // 排空
    wait (out_cnt >= 82);
    repeat (20) @(posedge clk);

    // 写CSV供绘图
    fd = $fopen(CSV_FILE, "w");
    $fdisplay(fd, "n,y_q31");
    for (n = 0; n < 82; n = n + 1)
      $fdisplay(fd, "%0d,%08X", n, cap[n]);
    $fclose(fd);

    // 自检：前82个输出与golden_asym前82行逐位相等
    for (n = 0; n < 82; n = n + 1)
      if (cap[n] !== golden[n]) begin
        $display("MISMATCH n=%0d hw=%h ref=%h", n, cap[n], golden[n]);
        err_cnt = err_cnt + 1;
      end
    if (out_cnt != 82) $fatal(1, "FAIL: 输出数=%0d（应82）", out_cnt);
    if (err_cnt != 0) $fatal(1, "FAIL: 冲激响应与golden不符 %0d处", err_cnt);
    $display("PASS Q18波形[%0s]: 82抽头冲激响应与golden逐位相等", TAG);
    $display("y[0]=%h  y[40]=%h  y[81]=%h", cap[0], cap[40], cap[81]);
    $display("VCD=%0s  CSV=%0s", VCD_FILE, CSV_FILE);
    $finish;
  end

  always @(posedge clk) begin
    if (dout_valid && dout_ready) begin
      if (out_cnt < 128) cap[out_cnt] = dout;
      out_cnt = out_cnt + 1;
    end
  end

  initial begin
    #5000000 $fatal(1, "FAIL: Q18波形仿真超时");
  end
endmodule

// 波形探针（仅端口，无逻辑）：给GTKWave一个只含关键信号的干净scope
module q18_wave_probe (
  input wire        clk,
  input wire        rstn,
  input wire        clr,
  input wire        din_valid,
  input wire        din_ready,
  input wire [15:0] din,
  input wire        dout_valid,
  input wire        dout_ready,
  input wire [31:0] dout
);
endmodule
